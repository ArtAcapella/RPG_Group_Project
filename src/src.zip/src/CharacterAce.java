public class CharacterAce {
	protected int sts, bos, qck, buf, tech, eyes, cool, lck, chrm, ice, inl, hst, hck, corp, str, snk;
	protected boolean laug, haug, remhk;

	/*
	 * sts - street smarts; bos - book smarts; qck - quick; buf - buff; tech - tech;
	 * eyes - eyes; cool - cool; lck - luck; chrm - charm; ice - ICE; inl -
	 * intelligence; hst - history; hck - hack; corp - corporate; snk - sneak; laug
	 * - leg augment; haug - hand augment; remhk - remote hacking; str - strength
	 */
	CharacterAce(int buf, int qck, int tech, int hck, int bos, int sts, int eyes, int cool, int chrm, int snk) {
		this.sts = sts;
		this.bos = bos;
		this.qck = qck;
		this.buf = buf;
		this.tech = tech;
		this.eyes = eyes;
		this.cool = cool;
		this.lck = lck;
		this.chrm = chrm;
		this.ice = ice;
		this.inl = inl;
		this.hst = hst;
		this.hck = hck;
		this.corp = corp;
		this.str = str;
		this.snk = snk;
		this.laug = laug;
		this.haug = haug;
		this.remhk = remhk;
	}
}